<a href="https://jekyll-themes.com">
<img src="https://img.shields.io/badge/featured%20on-JT-red.svg" height="20" alt="Jekyll Themes Shield">
</a>

# [Start Bootstrap - Business Frontpage Jekyll Version](https://webjeda.com/business-frontpage/)

Source: [Start Bootstrap - Business Frontpage](https://startbootstrap.com/template-overviews/business-frontpage/)

## Copyright and License

Copyright 2013-2019 Blackrock Digital LLC. Code released under the [MIT](https://github.com/BlackrockDigital/startbootstrap-business-frontpage/blob/gh-pages/LICENSE) license.
